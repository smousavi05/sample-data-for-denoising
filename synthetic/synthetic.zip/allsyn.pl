for ($i = 60; $i < 120; $i = $i + 10) {
    print "syn -M3.5/90/80/-70 -D0.2 -A45 -Osyn_$i.z -Gnmsz_12/$i.grn.0\n";
}
