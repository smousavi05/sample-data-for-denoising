print "perl fk.pl -Mnmsz/12 -N2048/0.1 ";
for ($i = 60; $i < 120; $i = $i + 10) {
    print "$i ";
}
print "\n";
